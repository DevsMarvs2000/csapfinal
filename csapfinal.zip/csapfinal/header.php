<html>
<head><title>Online Scheduling System</title>
<link href="admin/img/logo.png" rel="icon" type="image"> 
<script src="admin/js/jquery-1.7.2.min.js" type="text/javascript"></script>
<link href="admin/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link href="admin/css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
<link href="admin/css/style.css" rel="stylesheet" type="text/css" media="screen">


<script type="text/javascript" src="admin/js/bootstrap.js"></script>
<script type="text/javascript" src="admin/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="admin/js/bootstrap-typeahead.js"></script>


<!--- qtip --->
<script type="text/javascript" src="admin/js/qtip/jquery.qtip.min.js"></script>
<link href="admin/js/qtip/jquery.qtip.min.css" rel="stylesheet" type="text/css" media="screen, projection">






		<script type="text/javascript">
						jQuery(document).ready(function() {
				$('.typeahead').typeahead()
				
				  $('.carousel').carousel({
    interval: 4000
    })	
    })	
		</script>

</head>

