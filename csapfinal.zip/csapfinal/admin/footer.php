  <hr>

      <footer>
        <p>Copyright &copy; Colegio de San Antonio de Padua De La Salle Supervised School. All rights reserved.</p>
		<div class="pull-right_foot">
		BSIS 4
		</div>
		
      </footer>