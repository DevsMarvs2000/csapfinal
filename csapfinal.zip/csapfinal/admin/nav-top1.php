	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="branded">
		<img src="img/image.png" width="100" height="90">
 	</a> 
	<a class="brand">
	 <h1>BSIS Scheduling System</h1>
	 <div class="chmsc_nav"><font size="5" style="Bookman Old Style" color="white">Colegio de San Antonio de Padua - De La Salle Supervised School</font></div>
 	</a>

	
</div>
	</div>
	</div>