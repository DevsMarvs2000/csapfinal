<hr>

<footer>
  <p>Copyright &copy; Colegio de San Antonio de Padua - De La Salle Supervised School All rights reserved.</p>
<div class="pull-right_foot">
Programmed by: GROUP of Chrystal Niña Damiles
</div>

</footer>