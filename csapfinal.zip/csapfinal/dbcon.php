<?php 
$conn=mysqli_connect('localhost','root','',"css")or die(mysqli_error());

?>