	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="branded">
		<img src="img/image.png" width="100" height="90">
 	</a> 
	<a class="brand">
	 <h1>BSIS Scheduling System</h1>
	 <div class="chmsc_nav"><font size="5" color="white">Colegio de San Antonio de Padua - De La Salle Supervised School</font></div>
 	</a>
<div class="time_top">	
<font color="white">
  <?php
 $Today=date('m:d:y');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font>
<br>
	<a href="../index.php" class="btn btn-warning"><i class="icon-arrow-left icon-large"></i>&nbsp;Back to Home</a>
	
</div>
	</div>
	</div>
	</div>